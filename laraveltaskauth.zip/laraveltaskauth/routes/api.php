<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\TasksControllers;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:api')->get('/user', function (Request $request) {
//     return $request->user();
// });

// Public Routes
Route::post('/register', [AuthController::class, 'register']);
Route::post('/login', [AuthController::class, 'login']);
Route::get('/alltasks', [TasksControllers::class, 'alltasks']); // all users task which will also include their names

//Protected Routes
Route::group(['middleware' => ['auth:sanctum']], function(){

    //user
    Route::get('/profile', [AuthController::class, 'profile']); // user profile
    Route::post('/logout', [AuthController::class, 'logout']); // user logout

    //Tasks
    Route::get('/usertasks', [TasksControllers::class, 'usertaskslist']); //list user tasks
    Route::post('/tasks', [TasksControllers::class, 'store']); // create a new task
    Route::get('/usertasks/{id}', [TasksControllers::class, 'show']); //user single task
    Route::put('/usertasks/{id}', [TasksControllers::class, 'update']); // update user single task
    Route::delete('/usertasks/{id}', [TasksControllers::class, 'destroy']); // delete user single task
});