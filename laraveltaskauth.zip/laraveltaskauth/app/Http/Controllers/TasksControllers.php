<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Tasks;

class TasksControllers extends Controller
{
    // get all users tasks
    public function alltasks()
    {
        return response([
            'alltasks' => Tasks::orderBy('created_at', 'desc')->with('user:id,name')->get()
        ], 200);
    }

     // get user list of tasks
    public function usertaskslist()
    {
        $user_id = auth()->user()->id;
        $user = User::find($user_id);
        
        return response([
            'user_taskslist' => Tasks::where('user_id', $user->id)->orderBy('created_at', 'desc')->get()
        ], 200);
    }

    // get user single task
    public function show($id)
    {
        return response([
            'single_task' => Tasks::where('id', $id)->get()
        ], 200);
    }

    // create new Task
    public function store(Request $request)
    {
        $attrs = $request->validate([
            'title' => 'required|string',
            'description' => 'required|string'
        ]);

        $task = Tasks::create([
            'title' => $attrs['title'],
            'description' => $attrs['description'],
            'user_id' => auth()->user()->id
        ]);

        return response([
            'message' => 'Task created...',
            'task' =>$task
        ], 200);
    }

    // update a single task
    public function update(Request $request, $id)
    {

        $task = Tasks::find($id);

        if(!$task)
        {
            return response([
                'message' => 'Tasks not found'
            ], 403);
        }

        if($task->user_id != auth()->user()->id)
        {
             return response([
                'message' => 'Access denied!'
            ], 403);
        }

        $attrs = $request->validate([
            'title' => 'required|string',
            'desciption' => 'required|string'
        ]);

        $task->update([
            'title' => $attrs['title'],
            'description' => $attrs['description']
        ]);

        return response([
            'message' => 'Task updated...',
            'task' =>$task
        ], 200);
    }

    // delete a single task
    public function destroy($id)
    {
         $task = Tasks::find($id);

        if(!$task)
        {
            return response([
                'message' => 'Tasks not found'
            ], 403);
        }

        if($task->user_id != auth()->user()->id)
        {
             return response([
                'message' => 'Access denied!'
            ], 403);
        }

        $task->delete();

        return response([
            'message' => 'Task deleted...',
        ], 200);
    }
}